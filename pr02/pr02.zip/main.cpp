// =============================================================================
// VIZA654/CSCE646 at Texas A&M University
// Homework 1
// Created by Anton Agana based from Ariel Chisholm's template
// 05.23.2011
//
// This file is supplied with an associated makefile. Put both files in the same
// directory, navigate to that directory from the Linux shell, and type 'make'.
// This will create a program called 'pr01' that you can run by entering
// 'homework0' as a command in the shell.
//
// If you are new to programming in Linux, there is an
// excellent introduction to makefile structure and the gcc compiler here:
//
// http://www.cs.txstate.edu/labs/tutorials/tut_docs/Linux_Prog_Environment.pdf
//
// =============================================================================

#include <cstdlib>
#include <iostream>
#include <GLUT/glut.h>

#include <fstream>
#include <cassert>
#include <sstream>
#include <string>
#include <complex>
#include <cmath>

using namespace std;

#include "image.hpp"
#include "shape.hpp"

string option;
int samples = 1;
int strokeWidth = 2;
bool showEdge = true;
bool jittered = true;
int width, height;

RGBImage img;
Polygoni poly;

void fillMandelbrot( const RGB& c1, const RGB& c2, const RGB& c3,
                     int iters )
{
    int centerX = img.width() / 2;
    int centerY = img.height() / 2;

    const int THRES = 1e6;
    for(int y = 0; y < img.height() ; y++) {
        for(int x = 0; x < img.width(); x++) {

            complex<float> z((x-centerX)/(float)img.width() * 3.0 - 0.25, (y-centerY)/(float)img.height() * 3.0);
            complex<float> c = z;

            float val = std::abs(z);
            int i=0;
            while( i++ < iters && val < THRES )
            {
                z = z * z + c;
                val = std::abs(z);
            }

            float t = i / (float)iters;
            t = powf(t, 0.25);
            RGB color;
            if( t >= 1.0 )
                color = c1;
            else
                color = interpolate(c2, c3, t);

            img.setPixel(x, y, color);
        }
    }
}

void fillShape( const RGB& c, const RGB& cb, const Shape& s )
{
    int N = samples;
    float h = 1.0f / N;

    if( !jittered )
    {
        for(int y = 0; y < img.height() ; y++) {
            for(int x = 0; x < img.width(); x++) {

                // for this pixel, sample N^2 times
                int cnt = 0;
                float yy = y + 0.5 * h;
                for(int i=0;i<N;i++)
                {
                    float xx = x + 0.5 * h;

                    for(int j=0;j<N;j++)
                    {
                        if( s.isInside(Point2f(xx, yy)) ) cnt++;

                        xx += h;
                    }
                    yy += h;
                }

                float t = cnt / (float)(N * N);

                img.setPixel(x, y, interpolate(c, cb, t));
            }
        }
    }
    else
    {
        for(int y = 0; y < img.height() ; y++) {
            for(int x = 0; x < img.width(); x++) {

                // for this pixel, sample N^2 times
                int cnt = 0;
                float yy = y + 0.5 * h;
                for(int i=0;i<N;i++)
                {
                    float xx = x + 0.5 * h;
                    for(int j=0;j<N;j++)
                    {
                        float xxx = xx + h * rand()/(float)RAND_MAX;
                        float yyy = yy + h * rand()/(float)RAND_MAX;

                        if( s.isInside(Point2f(xxx, yyy)) ) cnt++;

                        xx += h;
                    }
                    yy += h;
                }

                float t = cnt / (float)(N * N);

                img.setPixel(x, y, interpolate(c, cb, t));
            }
        }
    }
}

void drawShape( const RGB& c, const Shape& s )
{
    int N = samples;
    float h = 1.0f / N;

    for(int y = 0; y < img.height() ; y++) {
        for(int x = 0; x < img.width(); x++) {

            // for this pixel, sample N^2 times
            int cnt = 0;
            float yy = y + 0.5 * h;
            for(int i=0;i<N;i++)
            {
                float xx = x + 0.5 * h;

                for(int j=0;j<N;j++)
                {
                    if( fabs(s.distanceTo(Point2f(xx, yy))) <=  strokeWidth ) cnt++;

                    xx += h;
                }
                yy += h;
            }

            float t = cnt / (float)(N * N);

            img.setPixel(x, y, interpolate(c, img.getPixel(x,y), t));
        }
    }
}

void fillPolygon( const RGB& c, const RGB& cb, const Polygoni& s )
{
    int N = samples;
    float h = 1.0f / N;

    if( !jittered )
    {
        for(int y = 0; y < img.height() ; y++) {
            for(int x = 0; x < img.width(); x++) {


                // for this pixel, sample N^2 times
                int cnt = 0;
                float yy = y + 0.5 * h;
                for(int i=0;i<N;i++)
                {
                    float xx = x + 0.5 * h;

                    for(int j=0;j<N;j++)
                    {
                        if( s.isInside_raycast(Point2f(xx, yy)) ) cnt++;

                        xx += h;
                    }
                    yy += h;
                }

                float t = cnt / (float)(N * N);

                img.setPixel(x, y, interpolate(c, cb, t));
            }
        }
    }
    else
    {
        for(int y = 0; y < img.height() ; y++) {
            for(int x = 0; x < img.width(); x++) {


                // for this pixel, sample N^2 times
                int cnt = 0;
                float yy = y + 0.5 * h;
                for(int i=0;i<N;i++)
                {
                    float xx = x + 0.5 * h;
                    for(int j=0;j<N;j++)
                    {
                        float xxx = xx + rand()/(float)RAND_MAX * h;
                        float yyy = yy + rand()/(float)RAND_MAX * h;

                        if( s.isInside_raycast(Point2f(xxx, yyy)) ) cnt++;

                        xx += h;
                    }
                    yy += h;
                }

                float t = cnt / (float)(N * N);

                img.setPixel(x, y, interpolate(c, cb, t));
            }
        }
    }
}

void drawPolygon( const RGB& c, const Polygoni& s )
{
    int N = samples;
    float h = 1.0f / N;

    for(int y = 0; y < img.height() ; y++) {
        for(int x = 0; x < img.width(); x++) {

            // for this pixel, sample N^2 times
            int cnt = 0;
            float yy = y + 0.5 * h;
            for(int i=0;i<N;i++)
            {
                float xx = x + 0.5 * h;

                for(int j=0;j<N;j++)
                {
                    float dist = numeric_limits<float>::max();
                    bool valid = false;
                    for(int k=0;k<s.e.size();k++)
                    {
                        Point2f p(xx, yy);

                        float dl = fabs(s.e[k].distanceTo( p ));
                        if( dl < strokeWidth ){

                            dist = dl;
                            Point2f p0 = s.v[k];
                            Point2f p1 = s.v[(k+1)%s.v.size()];
                            Vector2f p0p(p0, p), p1p(p1, p);
                            Vector2f p0p1(p0,p1), p1p0(p1,p0);
                            valid |= ((p0p.dot(p0p1) >= 0) && (p1p.dot(p1p0) >= 0));

                        }
                        else continue;
                    }

                    if( valid ) cnt++;

                    xx += h;
                }
                yy += h;
            }

            float t = cnt / (float)(N * N);

            img.setPixel(x, y, interpolate(c, img.getPixel(x, y), t));
        }
    }
}

void fillShaded( const RGB& c1, const RGB& c2,
                 const RGB& c3, const RGB& c4 )
{
    int N = samples;
    float h = 1.0f / N;

    int radius = 0.375 * height;
    float radius2 = radius * radius;
    int centerX = width / 2;
    int centerY = height / 2;
    Circle circ(centerX, centerY, radius);
    int shadeX = centerX - width / 16, shadeY = centerY + height / 16;

    for(int y = 0; y < img.height() ; y++) {
        for(int x = 0; x < img.width(); x++) {

            // for this pixel, sample N^2 times
            int cnt = 0;
            float yy = y + 0.5 * h;
            for(int i=0;i<N;i++)
            {
                float xx = x + 0.5 * h;

                for(int j=0;j<N;j++)
                {
                    float xxx = xx + (jittered?(h * rand() / (float)RAND_MAX):0);
                    float yyy = yy + (jittered?(h * rand() / (float)RAND_MAX):0);
                    if( circ.isInside(Point2f(xxx, yyy)) ) cnt++;

                    xx += h;
                }
                yy += h;
            }

            float t = cnt / (float)(N * N);

            RGB cIn, cOut;
            float tIn = sqrt(((x - shadeX)*(x-shadeX) + (y-shadeY)*(y-shadeY)) / (float)radius2);
            tIn = clamp(tIn, 0.0f, 1.0f);
            cIn = interpolate(c1, c2, tIn);

            float tOut = ((x / 640.0f) + (y / 320.0f)) / 2.0;
            tOut = clamp(tOut, 0.0f, 1.0f);
            cOut = interpolate(c3, c4, tOut);

            img.setPixel(x, y, interpolate(cIn, cOut, t));
        }
    }
}

float myfun(float x, float y)
{
    const float PI = 3.1415926;
    float py = (y - 256)/20.0;
    float px = fabs(x - 320) / 20.0;
    return (py - 5.0 * sin(4.0 * px + 0.5 * PI) * exp(-0.3 * px));
}

void setPixels( const string& option )
{
    if( option == "circle" )
    {
        Circle c(width/2, height/2, height*0.375);
        fillShape(RGB::white, RGB(0, 128, 0), c);
    }
    else if( option == "convex" )
    {
        Polygoni pg;
        pg.v.push_back(Point2i(256, 20));
        pg.v.push_back(Point2i(420, 128));
        pg.v.push_back(Point2i(375, 420));
        pg.v.push_back(Point2i(128, 375));
        pg.v.push_back(Point2i(100, 160));

        pg.genEdges();

        fillShape( RGB::yellow, RGB::blue, pg );
    }
    else if( option == "concave" )
    {
        Polygoni pg;
        pg.v.push_back(Point2i(256, 20));
        pg.v.push_back(Point2i(420, 128));
        pg.v.push_back(Point2i(250, 300));
        pg.v.push_back(Point2i(375, 420));
        pg.v.push_back(Point2i(128, 375));
        pg.v.push_back(Point2i(100, 160));
        pg.genEdges();

        fillPolygon(RGB::yellow, RGB::blue, pg );
    }
    else if( option == "star" )
    {
        Star s(width/2, height/2, 45, 5);
        fillShape(RGB::white, RGB(0, 0, 160), s);
    }
    else if( option == "star7" )
    {
        Star s(width/2, height/2, 80, 7);
        fillShape(RGB::white, RGB(0, 0, 160), s);
    }
    else if( option == "function" )
    {
        Function f(myfun);
        fillShape( RGB::yellow, RGB::red, f );
    }
    else if( option == "blobby" )
    {
        Blobby b;
        b.addCircle( Circle(width/4, height*0.8, 60) );
        b.addCircle( Circle(width/6, height/2, 50) );
        b.addCircle( Circle(width*0.5, height*0.7, 75) );
        b.addCircle( Circle(width*0.5, height/3, 150) );
        b.addCircle( Circle(width*0.75, height*0.6, 100) );

        fillShape( RGB::green, RGB::white, b );
    }
    else if( option == "shaded" )
    {
        RGB c1(32, 64, 255);
        RGB c2 = RGB::white;
        RGB c3(255, 150, 125);
        RGB c4(125, 255, 128);

        fillShaded( c1, c2, c3, c4 );
    }
    else if( option == "customized" )
    {
        poly.genEdges();
        fillPolygon( RGB::green, RGB::white, poly );
        if( showEdge )
            drawPolygon( RGB::black, poly );
    }
    else
    {
        RGB c1(32, 64, 255);
        RGB c2 = RGB::white;
        RGB c3(255, 150, 125);
        RGB c4(125, 255, 128);

        // invalid command, fill shaded by default
        fillShaded( c1, c2, c3, c4 );
    }
}


// =============================================================================
// OpenGL Display and Mouse Processing Functions.
//
// You can read up on OpenGL and modify these functions, as well as the commands
// in main(), to perform more sophisticated display or GUI behavior. This code
// will service the bare minimum display needs for most assignments.
// =============================================================================
static void windowResize(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,(w/2),0,(h/2),0,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    img.resize(w, h);
    setPixels( option );
}

static void windowDisplay(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glRasterPos2i(0,0);
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glDrawPixels(img.width(), img.height(), GL_RGB, GL_UNSIGNED_BYTE, img.raw_data());
    glFlush();
}

static void processMotion(int x, int y)
{
}

static void processMouse(int button, int state, int x, int y)
{
    switch( button )
    {
    case GLUT_LEFT_BUTTON:
    {
        if( state == GLUT_DOWN )
        {
            poly.v.push_back(Point2i(x, height-y));
            setPixels(option);
        }
        break;
    }
    case GLUT_RIGHT_BUTTON:
    {
        poly.v.clear();
        break;
    }
    default:
        break;
    }
    glutPostRedisplay();
}

static void processKeyboard(unsigned char key, int x, int y)
{
    switch( key )
    {
    case 27:
        exit(0);
    case 'e':
    {
        // toggle edge render
        showEdge = !showEdge;
        setPixels( option );
        glutPostRedisplay();
        break;
    }
    case 'j':
    {
        jittered = !jittered;
        cout << "using " << (jittered?"uniform jittered":"uniform") << " sampling." << endl;
        setPixels( option );
        glutPostRedisplay();
        break;
    }
    case '+':
    case '=':
    {
        samples++;
        samples = min(samples, 16);
        cout << "sample number per pixel: " << samples * samples << endl;
        setPixels( option );
        glutPostRedisplay();
        break;
    }
    case '-':
    case '_':
    {
        samples--;
        samples = max(samples, 1);
        cout << "sample number per pixel: " << samples * samples << endl;
        setPixels( option );
        glutPostRedisplay();
        break;
    }
    default:
        break;
    }
}

static void init(void)
{
    glClearColor(1,1,1,1); // Set background color.
}

void printHelp()
{
    printf("Usage: ./pr02 [option] [samples]\n");
    printf("valid options:\n");
    string ops[] = { "circle",
                     "convex",
                     "concave",
                     "star",
                     "function",
                     "blobby",
                     "shaded",
                     "customized"};

    for(int i=0;i<8;i++)
        cout << "\t" << ops[i] << endl;
    cout << "samples can be any integer in the range [1,8]" << endl;
}

// =============================================================================
// main() Program Entry
// =============================================================================
int main(int argc, char *argv[])
{
    if( argc < 2 )
    {
        printHelp();
    }

    if( argc < 2 )
        option = "invalid";
    else
        option = argv[1];

    if( argc < 3 )
        // default samples
        samples = 4;
    else
        samples = atoi(argv[2]);

    //initialize the global variables
    width = 640, height = 480;

    img.resize(width, height);
    // set the pixels based on the input option
    setPixels( option );


    // OpenGL Commands:
    // Once "glutMainLoop" is executed, the program loops indefinitely to all
    // glut functions.
    glutInit(&argc, argv);
    glutInitWindowPosition(100, 100); // Where the window will display on-screen.
    glutInitWindowSize(width, height);
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
    glutCreateWindow("Project 02");
    init();
    glutReshapeFunc(windowResize);
    glutDisplayFunc(windowDisplay);
    glutMouseFunc(processMouse);
    glutMotionFunc(processMotion);
    glutKeyboardFunc(processKeyboard);
    glutMainLoop();

    return 0; //This line never gets reached. We use it because "main" is type int.
}

