#ifndef IMAGE_HPP
#define IMAGE_HPP

#include "color.h"
using namespace Color;

template <typename T>
class Image
{
public:
    typedef T pixel_t;

    Image():w(0),h(0),pixmap(NULL){}
    Image(int w, int h):w(w),h(h),pixmap(new T[w*h]){}
    virtual ~Image(){ if( pixmap != NULL ) delete[] pixmap; }

    void resize(int width, int height)
    {
        w = width;
        h = height;
        if( pixmap != NULL ) delete[] pixmap;
        pixmap = new pixel_t[w * h];
    }

    int width() const{ return w;}
    int height() const { return h; }
    void setPixel(int x, int y, const pixel_t& p)
    {
        pixmap[y*w + x] = p;
    }

    pixel_t getPixel(int x, int y) const
    {
        return pixmap[y*w+x];
    }

    void fill(int x0, int y0, int width, int height, const T& c)
    {
        int y1 = y0 + height;
        int x1 = x0 + width;
        for(int y=y0;y<y1;y++)
            for(int x=x0;x<x1;x++)
                pixmap[y*w+x] = c;
    }

    void fill(const T& c)
    {
        fill(0, 0, w, h, c);
    }

    void fillPixmap(const T* p)
    {
        memcpy(pixmap, p, sizeof(T)*w*h);
    }

    T* raw_data() const { return pixmap; }

protected:
    int w, h;
    T* pixmap;
};

typedef Image<RGB> RGBImage;

#endif // IMAGE_HPP
