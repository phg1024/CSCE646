#ifndef IMAGEOPERATOR_H
#define IMAGEOPERATOR_H

template <typename T>
class ImageOperator
{
public:
    typedef T image_t;
    enum Axis{
        Horizontal,
        Vertical
    };

    static image_t flip(const image_t& img, Axis ax);
};

template <typename T>
T ImageOperator<T>::flip(const T &img, Axis ax)
{
    typedef T image_t;
    typedef typename image_t::pixel_t pixel_t;
    int w = img.width();
    int h = img.height();

    image_t res(w, h);
    if( ax == Vertical )
    {
        cout << "flip the image vertically." << endl;

        for(int i=0;i<h;i++)
        {
            int y = h - 1 - i;
            for(int x=0;x<w;x++)
            {
                res.setPixel(x, y, img.getPixel(x, i));
            }
        }
    }
    else if( ax == Horizontal )
    {
        cout << "flip the image horizontally." << endl;

        for(int y=0;y<h;y++)
        {
            for(int x=0, xx=w-1;x<w;x++, xx--)
            {
                res.setPixel(xx, y, img.getPixel(x, y));
            }
        }
    }
    return res;
}

#endif // IMAGEOPERATOR_H
