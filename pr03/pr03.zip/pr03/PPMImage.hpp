#ifndef PPMIMAGE_HPP
#define PPMIMAGE_HPP

#include "image.hpp"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

template <typename T>
class PPMImage : public Image<T>
{
public:
    typedef T pixel_t;

    PPMImage():Image<T>(){}
    PPMImage(int w, int h):Image<T>(w, h){}
    PPMImage(const string& filename):Image<T>()
    {
        read(filename);
    }
    PPMImage(const PPMImage& img):
        id(img.id), comments(img.comments),
        maxVal(img.maxVal)
    {
        this->w = img.width();
        this->h = img.height();
        this->pixmap = new pixel_t[this->w * this->h];
        memcpy( this->pixmap, img.raw_data(), sizeof(pixel_t) * this->w * this->h );
    }

    virtual ~PPMImage(){
        if( this->pixmap != NULL )
        {
            delete[] this->pixmap;
            this->pixmap = NULL;
        }
    }

    PPMImage& operator=(const PPMImage& rhs)
    {
        if( this != &rhs )
        {
            if( this->pixmap != NULL )
                delete[] this->pixmap;

            this->pixmap = new pixel_t[ rhs.width() * rhs.height() ];

            memcpy( this->pixmap, rhs.raw_data(), sizeof( pixel_t) * rhs.width() * rhs.height() );
            this->w = rhs.width();
            this->h = rhs.height();
            this->id = rhs.id;
            this->maxVal = rhs.maxVal;
            this->comments = rhs.comments;
        }
        return (*this);
    }

    void write(const string& filename);

protected:
    void read(const string& filename);

private:
    // identifier
    string id;
    vector<string> comments;
    int maxVal;
};

template <typename T>
void PPMImage<T>::read(const string &filename)
{
    ifstream file;
    file.open(filename.c_str(), ios::in);

    if( !file )
    {
        cerr << "invalid file!" << endl;
        return;
    }

    getline(file, id);
    cout << "magic number: " << id << endl;

    bool sizeSet(false), maxValSet(false);

    string buf;
    while( true )
    {
        getline(file, buf);
        if( buf[0] == '#' )
        {
            // comment line
            comments.push_back( buf );
        }
        else if( !sizeSet )
        {
            sscanf(buf.c_str(), "%d %d", &this->w, &this->h);
            cout << "size: " << this->w << "x" << this->h << endl;
            sizeSet = true;
        }
        else if( !maxValSet )
        {
            sscanf(buf.c_str(), "%d", &maxVal);
            cout << "max val: " << maxVal << endl;
            maxValSet = true;
        }

        if( id == "P1" || id == "P4" )
            if( sizeSet ) break;

        // reached the end of the header
        if( maxValSet ) break;
    }

    if( id == "P1" )
    {
        this->pixmap = new pixel_t[this->w * this->h];
        int offset = 0;
        for(int i=0;i<this->h;i++)
            for(int j=0;j<this->w;j++)
            {
                char c;
                file >> c;
                if( c == '\n' ) continue;
                c = (c=='1')?0:255;
                this->pixmap[offset].r = c;
                this->pixmap[offset].g = c;
                this->pixmap[offset++].b = c;
            }
    }
    else if( id == "P2" )
    {
        this->pixmap = new pixel_t[this->w * this->h];
        int offset = 0;
        for(int i=0;i<this->h;i++)
            for(int j=0;j<this->w;j++)
            {
                int val;
                file >> val;
                this->pixmap[offset].r = val;
                this->pixmap[offset].g = val;
                this->pixmap[offset++].b = val;
            }
    }
    else if( id == "P3" )
    {
        this->pixmap = new pixel_t[this->w * this->h];
        int offset = 0;
        for(int i=0;i<this->h;i++)
            for(int j=0;j<this->w;j++)
            {
                int r, g, b;
                file >> r >> g >> b;
                this->pixmap[offset].r = r;
                this->pixmap[offset].g = g;
                this->pixmap[offset++].b = b;
            }
    }
    else if( id == "P4" )
    {
        // binary gray scale
        int BSIZE = this->w * this->h / 8;
        cout << "BSIZE = " << BSIZE << endl;
        char* buffer = new char[BSIZE];
        file.read(buffer, sizeof(unsigned char) * BSIZE);

        this->pixmap = new pixel_t[this->w * this->h];
        int offset = 0, idx = 0;
        for(int i=0;i<this->h;i++)
            for(int j=0;j<this->w;j++)
            {
                int r = (7 - idx % 8);
                unsigned char c =  (1 - ((buffer[idx/8] >> r) & 0x1)) * 255;
                idx++;
                this->pixmap[offset].r = c;
                this->pixmap[offset].g = c;
                this->pixmap[offset++].b = c;
            }
    }
    else if( id == "P5" )
    {
        // binary gray scale
        int BSIZE = this->w * this->h;
        char* buffer = new char[BSIZE];
        file.read(buffer, sizeof(unsigned char) * BSIZE);

        this->pixmap = new pixel_t[BSIZE];
        int offset = 0, idx = 0;
        for(int i=0;i<this->h;i++)
            for(int j=0;j<this->w;j++)
            {
                unsigned char c = buffer[idx++];
                this->pixmap[offset].r = c;
                this->pixmap[offset].g = c;
                this->pixmap[offset++].b = c;
            }
    }
    else if( id == "P6" )
    {
        int BSIZE = this->w * this->h;
        this->pixmap = new pixel_t[BSIZE];
        file.read((char*)this->pixmap, sizeof(char) * BSIZE * 3);
    }
    file.close();
}

template <typename T>
void PPMImage<T>::write(const string &filename)
{
    cout << "writing to " << filename << endl;
    ofstream file;
    file.open(filename.c_str(), ios::out);

    // write the magic number
    file << id << endl;
    file << this->w << ' ' << this->h << endl;
    for(int i=0;i<comments.size();i++)
        file << comments[i] << endl;
    file << this->maxVal << endl;

    if( id == "P1" )
    {
        int offset = 0;
        for(int i=0;i<this->h;i++)
        {
            for(int j=0;j<this->w;j++)
            {
                char c = (this->pixmap[offset++].r==0)?'1':'0';
                file << c;
            }
            file << endl;
        }
    }
    else if( id == "P2" )
    {
        int offset = 0;
        for(int i=0;i<this->h;i++)
        {
            for(int j=0;j<this->w;j++)
            {
                file << (int) this->pixmap[offset++].r << ' ';
            }
            file << endl;
        }
    }
    else if( id == "P3" )
    {
        int offset = 0;
        for(int i=0;i<this->h;i++)
        {
            for(int j=0;j<this->w;j++)
            {
                file << (int) this->pixmap[offset].r << ' '
                << (int) this->pixmap[offset].g << ' '
                << (int) this->pixmap[offset++].b << ' ';
            }
            file << endl;
        }
    }
    else if( id == "P4" )
    {
        int offset = 0;
        for(int i=0;i<this->h;i++)
        {
            for(int j=0;j<this->w;j++)
            {
                file << (int) this->pixmap[offset++].r << ' ';
            }
            file << endl;
        }
    }
    else if( id == "P5" )
    {
        unsigned char* buf = new unsigned char[this->w * this->h];
        int offset = 0;
        for(int i=0;i<this->h;i++)
        {
            for(int j=0;j<this->w;j++)
            {
                buf[i*this->w+j] = this->pixmap[offset++].r;
            }
        }
        file.write((char*)buf, sizeof(char)*this->w*this->h);
    }
    else if( id == "P6" )
    {
        cout << id << endl;
        unsigned char* buf = new unsigned char[this->w * this->h * 3];
        int offset = 0;
        int idx = 0;
        for(int i=0;i<this->h;i++)
        {
            for(int j=0;j<this->w;j++)
            {
                buf[idx++] = this->pixmap[offset].r;
                buf[idx++] = this->pixmap[offset].g;
                buf[idx++] = this->pixmap[offset++].b;
            }
        }
        file.write((char*)buf, sizeof(char)*this->w*this->h*3);
    }

    file.close();
}

typedef PPMImage<RGB> PPMImage_RGB;

#endif // PPMIMAGE_HPP
